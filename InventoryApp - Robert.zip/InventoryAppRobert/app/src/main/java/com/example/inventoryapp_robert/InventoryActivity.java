package com.example.inventoryapp_robert;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    DatabaseHelper databaseHelper;
    EditText editItemName, editQuantity;
    Button buttonAddItem, buttonSms;
    ListView listInventory;

    ArrayList<String> inventoryList;
    ArrayList<Integer> itemIds;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonSms = findViewById(R.id.buttonSms);
        listInventory = findViewById(R.id.listInventory);

        inventoryList = new ArrayList<>();
        itemIds = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                inventoryList
        );

        listInventory.setAdapter(adapter);

        loadInventory();

        buttonAddItem.setOnClickListener(v -> addItem());

        // Delete item when clicked
        listInventory.setOnItemClickListener((parent, view, position, id) -> {
            int itemId = itemIds.get(position);
            databaseHelper.deleteItem(itemId);
            loadInventory();
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
        });

        // SMS button
        buttonSms.setOnClickListener(v -> checkSmsPermission());
    }

    // =====================
    // INVENTORY METHODS
    // =====================

    private void addItem() {
        String name = editItemName.getText().toString().trim();
        String qtyStr = editQuantity.getText().toString().trim();

        if (name.isEmpty() || qtyStr.isEmpty()) {
            Toast.makeText(this, "Enter item and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(qtyStr);
        databaseHelper.addItem(name, quantity);

        editItemName.setText("");
        editQuantity.setText("");

        loadInventory();
    }

    private void loadInventory() {
        inventoryList.clear();
        itemIds.clear();

        Cursor cursor = databaseHelper.getAllItems();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            int qty = cursor.getInt(2);

            inventoryList.add(name + " - Qty: " + qty);
            itemIds.add(id);
        }

        cursor.close();
        adapter.notifyDataSetChanged();
    }

    // =====================
    // SMS PERMISSION + SEND
    // =====================

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            sendSmsAlert();

        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                sendSmsAlert();

            } else {
                Toast.makeText(
                        this,
                        "SMS permission denied. App will continue without notifications.",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    private void sendSmsAlert() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    "19197489495",   // Emulator-safe test number
                    null,
                    "Inventory Alert: Check your inventory levels.",
                    null,
                    null
            );

            Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }
}
